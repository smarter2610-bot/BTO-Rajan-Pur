package com.btorajanpur.dpm;

import android.app.Activity;
import android.content.ClipData;
import android.content.ContentResolver;
import android.content.ContentValues;
import android.content.Context;
import android.content.Intent;
import android.net.Uri;
import android.os.Build;
import android.os.Environment;
import android.provider.MediaStore;

import androidx.core.content.FileProvider;

import java.io.File;
import java.io.FileOutputStream;
import java.io.IOException;
import java.io.OutputStream;

/** File saving (Downloads) and sharing helpers. */
final class FileHelper {

    static final String FOLDER = "BTO Daily Reports";

    private FileHelper() {
    }

    static String where() {
        return Build.VERSION.SDK_INT >= 29
                ? "Downloads/" + FOLDER
                : "app Downloads folder";
    }

    /** Saves to the public Downloads folder (Android 10+) or the app's Download folder. */
    static Uri saveToDownloads(Context ctx, String name, String mime, byte[] data) throws IOException {
        if (Build.VERSION.SDK_INT >= 29) {
            ContentResolver resolver = ctx.getContentResolver();
            ContentValues cv = new ContentValues();
            cv.put(MediaStore.MediaColumns.DISPLAY_NAME, name);
            cv.put(MediaStore.MediaColumns.MIME_TYPE, mime);
            cv.put(MediaStore.MediaColumns.RELATIVE_PATH, Environment.DIRECTORY_DOWNLOADS + "/" + FOLDER);
            Uri uri = resolver.insert(MediaStore.Downloads.EXTERNAL_CONTENT_URI, cv);
            if (uri == null) throw new IOException("Could not create file");
            OutputStream os = resolver.openOutputStream(uri);
            if (os == null) throw new IOException("Could not open file");
            try {
                os.write(data);
            } finally {
                os.close();
            }
            return uri;
        }
        File base = ctx.getExternalFilesDir(Environment.DIRECTORY_DOWNLOADS);
        if (base == null) base = ctx.getFilesDir();
        File dir = new File(base, FOLDER);
        //noinspection ResultOfMethodCallIgnored
        dir.mkdirs();
        File f = new File(dir, name);
        FileOutputStream os = new FileOutputStream(f);
        try {
            os.write(data);
        } finally {
            os.close();
        }
        return Uri.fromFile(f);
    }

    /** Writes a temporary copy and returns a shareable content:// Uri. */
    static Uri cacheForShare(Context ctx, String name, byte[] data) throws IOException {
        File dir = new File(ctx.getCacheDir(), "exports");
        //noinspection ResultOfMethodCallIgnored
        dir.mkdirs();
        File[] old = dir.listFiles();
        if (old != null) for (File o : old) //noinspection ResultOfMethodCallIgnored
            o.delete();
        File f = new File(dir, name);
        FileOutputStream os = new FileOutputStream(f);
        try {
            os.write(data);
        } finally {
            os.close();
        }
        return FileProvider.getUriForFile(ctx, ctx.getPackageName() + ".fileprovider", f);
    }

    static void share(final Activity act, final Uri uri, final String mime, final String name) {
        act.runOnUiThread(new Runnable() {
            @Override
            public void run() {
                Intent i = new Intent(Intent.ACTION_SEND);
                i.setType(mime);
                i.putExtra(Intent.EXTRA_STREAM, uri);
                i.putExtra(Intent.EXTRA_SUBJECT, name);
                i.setClipData(ClipData.newRawUri(name, uri));
                i.addFlags(Intent.FLAG_GRANT_READ_URI_PERMISSION);
                act.startActivity(Intent.createChooser(i, "Share report"));
            }
        });
    }
}
