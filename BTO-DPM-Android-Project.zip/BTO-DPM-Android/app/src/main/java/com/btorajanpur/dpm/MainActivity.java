package com.btorajanpur.dpm;

import android.annotation.SuppressLint;
import android.app.Activity;
import android.content.ActivityNotFoundException;
import android.content.Intent;
import android.net.Uri;
import android.os.Bundle;
import android.view.ViewGroup;
import android.webkit.ValueCallback;
import android.webkit.JavascriptInterface;
import android.webkit.WebChromeClient;
import android.webkit.WebResourceRequest;
import android.webkit.WebResourceResponse;
import android.webkit.WebSettings;
import android.webkit.WebView;
import android.webkit.WebViewClient;
import android.widget.FrameLayout;

import androidx.webkit.WebViewAssetLoader;

import org.json.JSONObject;

/**
 * Hosts the offline Daily Progress Manager web app (assets/index.html) and
 * provides native JPG / PDF export, save-to-Downloads and share.
 */
public class MainActivity extends Activity {

    private static final int REQ_FILE = 101;
    private static final String HOST = "appassets.androidplatform.net";

    private FrameLayout root;
    private WebView web;
    private ValueCallback<Uri[]> fileCallback;
    private ReportExporter exporter;

    @SuppressLint({"SetJavaScriptEnabled", "AddJavascriptInterface"})
    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        try {
            // Must be called before any WebView is created (needed for full-page capture).
            WebView.enableSlowWholeDocumentDraw();
        } catch (Throwable ignored) {
        }
        getWindow().setStatusBarColor(0xFF0B2545);

        root = new FrameLayout(this);
        setContentView(root);

        web = new WebView(this);
        root.addView(web, new FrameLayout.LayoutParams(
                ViewGroup.LayoutParams.MATCH_PARENT, ViewGroup.LayoutParams.MATCH_PARENT));

        WebSettings s = web.getSettings();
        s.setJavaScriptEnabled(true);
        s.setDomStorageEnabled(true);      // enables IndexedDB / localStorage
        s.setDatabaseEnabled(true);
        s.setAllowFileAccess(false);
        s.setAllowContentAccess(false);
        s.setSupportZoom(false);
        s.setBuiltInZoomControls(false);

        final WebViewAssetLoader loader = new WebViewAssetLoader.Builder()
                .setDomain(HOST)
                .addPathHandler("/assets/", new WebViewAssetLoader.AssetsPathHandler(this))
                .build();

        web.setWebViewClient(new WebViewClient() {
            @Override
            public WebResourceResponse shouldInterceptRequest(WebView view, WebResourceRequest request) {
                return loader.shouldInterceptRequest(request.getUrl());
            }

            @Override
            public boolean shouldOverrideUrlLoading(WebView view, WebResourceRequest request) {
                Uri u = request.getUrl();
                if (HOST.equals(u.getHost())) return false;
                try {
                    startActivity(new Intent(Intent.ACTION_VIEW, u));
                } catch (ActivityNotFoundException ignored) {
                }
                return true;
            }
        });

        web.setWebChromeClient(new WebChromeClient() {
            @Override
            public boolean onShowFileChooser(WebView w, ValueCallback<Uri[]> callback,
                                             FileChooserParams params) {
                if (fileCallback != null) fileCallback.onReceiveValue(null);
                fileCallback = callback;
                try {
                    startActivityForResult(params.createIntent(), REQ_FILE);
                } catch (ActivityNotFoundException e) {
                    fileCallback = null;
                    return false;
                }
                return true;
            }
        });

        exporter = new ReportExporter(this, root, new ReportExporter.Callback() {
            @Override
            public void done(String message, boolean error) {
                notifyWeb(message, error);
            }
        });
        web.addJavascriptInterface(new Bridge(), "AndroidBridge");

        web.loadUrl("https://" + HOST + "/assets/index.html");
    }

    /** Called by the web app. Runs only for pages served from our own asset origin. */
    private final class Bridge {
        @JavascriptInterface
        public void exportReport(final String html, final String baseName,
                                 final String type, final boolean share) {
            runOnUiThread(new Runnable() {
                @Override
                public void run() {
                    exporter.export(html, baseName, type, share);
                }
            });
        }

        @JavascriptInterface
        public void saveText(final String name, final String text, final String mime) {
            new Thread(new Runnable() {
                @Override
                public void run() {
                    try {
                        FileHelper.saveToDownloads(MainActivity.this, name, mime, text.getBytes("UTF-8"));
                        notifyWeb("Saved: " + name + " (" + FileHelper.where() + ")", false);
                    } catch (Exception e) {
                        notifyWeb("Could not save the file.", true);
                    }
                }
            }).start();
        }
    }

    private void notifyWeb(final String message, final boolean error) {
        runOnUiThread(new Runnable() {
            @Override
            public void run() {
                if (web == null) return;
                web.evaluateJavascript("window.__nativeDone&&window.__nativeDone("
                        + JSONObject.quote(message == null ? "" : message) + "," + error + ")", null);
            }
        });
    }

    @Override
    protected void onActivityResult(int requestCode, int resultCode, Intent data) {
        if (requestCode == REQ_FILE) {
            if (fileCallback != null) {
                fileCallback.onReceiveValue(WebChromeClient.FileChooserParams.parseResult(resultCode, data));
                fileCallback = null;
            }
            return;
        }
        super.onActivityResult(requestCode, resultCode, data);
    }

    @Override
    public void onBackPressed() {
        web.evaluateJavascript("window.__androidBack?window.__androidBack():false", new ValueCallback<String>() {
            @Override
            public void onReceiveValue(String value) {
                if (!"true".equals(value)) finish();
            }
        });
    }

    @Override
    protected void onPause() {
        super.onPause();
        web.onPause();
    }

    @Override
    protected void onResume() {
        super.onResume();
        web.onResume();
    }

    @Override
    protected void onDestroy() {
        if (web != null) {
            root.removeView(web);
            web.destroy();
        }
        super.onDestroy();
    }
}
