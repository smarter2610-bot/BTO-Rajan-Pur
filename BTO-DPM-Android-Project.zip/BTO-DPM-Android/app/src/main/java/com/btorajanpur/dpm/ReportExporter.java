package com.btorajanpur.dpm;

import android.app.Activity;
import android.graphics.Bitmap;
import android.graphics.Canvas;
import android.graphics.Color;
import android.graphics.Paint;
import android.graphics.RectF;
import android.graphics.pdf.PdfDocument;
import android.net.Uri;
import android.os.Handler;
import android.os.Looper;
import android.view.ViewGroup;
import android.webkit.ValueCallback;
import android.webkit.WebSettings;
import android.webkit.WebView;
import android.webkit.WebViewClient;
import android.widget.FrameLayout;

import java.io.ByteArrayOutputStream;

/**
 * Renders the report HTML in an off-screen WebView (794 CSS px wide = A4 at 96 dpi),
 * captures it as a bitmap, and saves/shares it as a sharp JPG or A4 PDF.
 */
final class ReportExporter {

    interface Callback {
        void done(String message, boolean error);
    }

    private static final int REPORT_CSS_WIDTH = 794;
    private static final int REPORT_MIN_CSS_HEIGHT = 1123;
    private static final long MAX_PIXELS = 30000000L;

    private final Activity act;
    private final FrameLayout host;
    private final Callback cb;
    private final Handler handler = new Handler(Looper.getMainLooper());
    private boolean busy = false;

    ReportExporter(Activity act, FrameLayout host, Callback cb) {
        this.act = act;
        this.host = host;
        this.cb = cb;
    }

    /** Must be called on the UI thread. */
    void export(String html, String base, String type, boolean share) {
        if (busy) {
            cb.done("Another export is still running.", true);
            return;
        }
        busy = true;
        float density = act.getResources().getDisplayMetrics().density;
        int wPx = Math.round(REPORT_CSS_WIDTH * density);
        float k = wPx / (float) REPORT_CSS_WIDTH;

        WebView wv = new WebView(act);
        WebSettings s = wv.getSettings();
        s.setJavaScriptEnabled(true);
        s.setUseWideViewPort(true);
        s.setLoadWithOverviewMode(false);
        s.setAllowFileAccess(false);
        s.setTextZoom(100);
        wv.setBackgroundColor(Color.WHITE);

        // Placed behind the main WebView so it is "visible" to the system but never seen.
        FrameLayout.LayoutParams lp = new FrameLayout.LayoutParams(wPx, Math.round(REPORT_MIN_CSS_HEIGHT * k));
        host.addView(wv, 0, lp);

        new Job(wv, base, type, share, wPx, k).start(html);
    }

    private final class Job {
        final WebView wv;
        final String base;
        final String type;
        final boolean share;
        final int wPx;
        final float k;
        int hPx;
        int attempt = 0;

        Job(WebView wv, String base, String type, boolean share, int wPx, float k) {
            this.wv = wv;
            this.base = base;
            this.type = type;
            this.share = share;
            this.wPx = wPx;
            this.k = k;
        }

        void start(String html) {
            wv.setWebViewClient(new WebViewClient() {
                private boolean started;

                @Override
                public void onPageFinished(WebView view, String url) {
                    if (started) return;
                    started = true;
                    handler.postDelayed(new Runnable() {
                        @Override
                        public void run() {
                            measure();
                        }
                    }, 500);
                }
            });
            wv.loadDataWithBaseURL(null, html, "text/html", "UTF-8", null);
        }

        void measure() {
            wv.evaluateJavascript("(function(){return Math.ceil(document.documentElement.scrollHeight);})()",
                    new ValueCallback<String>() {
                        @Override
                        public void onReceiveValue(String v) {
                            int css = REPORT_MIN_CSS_HEIGHT;
                            try {
                                css = Integer.parseInt((v == null ? "" : v).replace("\"", "").trim());
                            } catch (Exception ignored) {
                            }
                            css = Math.max(css, REPORT_MIN_CSS_HEIGHT);
                            hPx = Math.round(css * k);
                            if ((long) wPx * hPx > MAX_PIXELS) {
                                fail("This report is too long to export as one page.");
                                return;
                            }
                            ViewGroup.LayoutParams lp = wv.getLayoutParams();
                            lp.height = hPx;
                            wv.setLayoutParams(lp);
                            handler.postDelayed(new Runnable() {
                                @Override
                                public void run() {
                                    capture();
                                }
                            }, 700);
                        }
                    });
        }

        void capture() {
            Bitmap bmp;
            try {
                bmp = Bitmap.createBitmap(wPx, hPx, Bitmap.Config.ARGB_8888);
            } catch (OutOfMemoryError e) {
                fail("Not enough memory to render the report.");
                return;
            }
            Canvas c = new Canvas(bmp);
            c.drawColor(Color.WHITE);
            wv.draw(c);

            // The navy header must not be white; if it is, the WebView has not painted yet.
            int probeY = Math.min(hPx - 1, Math.round(10 * k));
            boolean blank = bmp.getPixel(wPx / 8, probeY) == Color.WHITE;
            if (blank) {
                bmp.recycle();
                if (attempt < 3) {
                    attempt++;
                    handler.postDelayed(new Runnable() {
                        @Override
                        public void run() {
                            capture();
                        }
                    }, 800);
                } else {
                    fail("Could not render the report on this device.");
                }
                return;
            }
            cleanup();
            encode(bmp);
        }

        void cleanup() {
            host.removeView(wv);
            wv.destroy();
        }

        void fail(String msg) {
            cleanup();
            busy = false;
            cb.done(msg, true);
        }

        void encode(final Bitmap bmp) {
            new Thread(new Runnable() {
                @Override
                public void run() {
                    try {
                        boolean pdf = "pdf".equals(type);
                        byte[] data = pdf ? toPdf(bmp) : toJpg(bmp);
                        String name = base + (pdf ? ".pdf" : ".jpg");
                        String mime = pdf ? "application/pdf" : "image/jpeg";
                        if (share) {
                            Uri u = FileHelper.cacheForShare(act, name, data);
                            FileHelper.share(act, u, mime, name);
                            cb.done("", false);
                        } else {
                            FileHelper.saveToDownloads(act, name, mime, data);
                            cb.done("Saved: " + name + " (" + FileHelper.where() + ")", false);
                        }
                    } catch (Exception e) {
                        cb.done("Export failed. Please try again.", true);
                    } finally {
                        bmp.recycle();
                        busy = false;
                    }
                }
            }).start();
        }
    }

    private static byte[] toJpg(Bitmap bmp) {
        ByteArrayOutputStream out = new ByteArrayOutputStream();
        bmp.compress(Bitmap.CompressFormat.JPEG, 95, out);
        return out.toByteArray();
    }

    /** One A4 page (595 x 842 pt); the report is scaled to fit without cropping. */
    private static byte[] toPdf(Bitmap bmp) throws java.io.IOException {
        final float pw = 595f, ph = 842f;
        PdfDocument doc = new PdfDocument();
        try {
            PdfDocument.PageInfo info = new PdfDocument.PageInfo.Builder(595, 842, 1).create();
            PdfDocument.Page page = doc.startPage(info);
            float ratio = (float) bmp.getHeight() / bmp.getWidth();
            float w = pw, h = pw * ratio;
            if (h > ph) {
                h = ph;
                w = ph / ratio;
            }
            float x = (pw - w) / 2f;
            Paint p = new Paint(Paint.FILTER_BITMAP_FLAG | Paint.ANTI_ALIAS_FLAG);
            page.getCanvas().drawBitmap(bmp, null, new RectF(x, 0, x + w, h), p);
            doc.finishPage(page);
            ByteArrayOutputStream out = new ByteArrayOutputStream();
            doc.writeTo(out);
            return out.toByteArray();
        } finally {
            doc.close();
        }
    }
}
