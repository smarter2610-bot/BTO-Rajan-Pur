# BTO Rajan Pur – Daily Progress Manager (Android, Java)

Package: com.btorajanpur.dpm | minSdk 24 | targetSdk 34 | No internet permission needed.

## Structure
- app/src/main/java/com/btorajanpur/dpm/MainActivity.java   – WebView host, back button, file picker, JS bridge
- app/src/main/java/com/btorajanpur/dpm/ReportExporter.java – report -> JPG / A4 PDF (native)
- app/src/main/java/com/btorajanpur/dpm/FileHelper.java     – save to Downloads, share
- app/src/main/assets/index.html                            – the app screens and data (IndexedDB)

## Build option A: Android Studio (PC)
1. Install Android Studio (latest). File > Open > select this folder.
2. Wait for Gradle sync (accept Gradle 8.7 / JDK 17 if asked).
3. Build > Build Bundle(s) / APK(s) > Build APK(s).
4. APK: app/build/outputs/apk/debug/app-debug.apk -> copy to phone and install.

## Build option B: GitHub Actions (no PC)
1. Create a free GitHub repository and upload everything in this folder (including the .github folder).
2. Open the Actions tab > "Build APK" > Run workflow.
3. When it finishes, download "BTO-Daily-Progress-Manager-APK" from the run page.

## Saved files
JPG/PDF/backup files are saved in Downloads/BTO Daily Reports (Android 10+).
Share JPG / Share PDF open the normal Android share sheet (WhatsApp etc.).
